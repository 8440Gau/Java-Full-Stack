package Jwt.making;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MakingApplicationTests {

	@Test
	void contextLoads() {
	}

}
